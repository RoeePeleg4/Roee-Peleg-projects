package com.example.projectrp;

import static com.example.projectrp.SignUpActivity.isInteger;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
/**
 * The class activity that allows the user to change his details
 */
public class DetailsActivity extends AppCompatActivity implements View.OnClickListener {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Button btnBackDetails;
    Button btnSaveUsersChanges;
    EditText etUserId;
    EditText etUserName;
    EditText etFname;
    EditText etUserAddress;
    EditText etUserCity;
    EditText etCreditNumber;
    EditText etUserPassword;
    EditText etUserPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        initButtons();
        initTextView();
        setTexts();
    }

    public void setTexts(){
        etUserId.setText(User.currentUser.getUserID());
        etUserName.setText(User.currentUser.getUserFirstName());
        etFname.setText(User.currentUser.getUserLastName());
        etUserAddress.setText(User.currentUser.getAddress());
        etUserCity.setText(User.currentUser.getCity());
        etCreditNumber.setText(User.currentUser.getCreditNumber());
        etUserPassword.setText(User.currentUser.getPassword());
        etUserPhoneNumber.setText(User.currentUser.getPhoneNumber());
    }

    public void initButtons(){
        btnSaveUsersChanges = findViewById(R.id.btnSaveUsersChanges);
        btnBackDetails=findViewById(R.id.btnBackDetails);
        btnSaveUsersChanges.setOnClickListener(this);
        btnBackDetails.setOnClickListener(this);
    }

    public void initTextView(){
        etUserPhoneNumber = findViewById(R.id.etUserPhoneNumber);
        etUserId =findViewById(R.id.etUserId);
        etUserName =findViewById(R.id.etUserName);
        etFname=findViewById(R.id.etFname);
        etUserAddress =findViewById(R.id.etUserAddress);
        etUserCity =findViewById(R.id.etUserCity);
        etCreditNumber=findViewById(R.id.etCreditNumber);
        etUserPassword =findViewById(R.id.etUserPasswordDetails);
    }

    @Override
    public void onClick(View view) {

        if (view == btnBackDetails){
            backToMain();
        }else if (view == btnSaveUsersChanges){
            User user = new User(etUserId.getText().toString() , etUserName.getText().toString() , etCreditNumber.getText().toString() , etUserAddress.getText().toString() , etFname.getText().toString() , etUserCity.getText().toString() , etUserPassword.getText().toString() , etUserPhoneNumber.getText().toString() , User.currentUser.isManager());
            if (!Users.checkIfIdOk(user)) {
                Toast.makeText(this, "ID is already taken", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isPasswordlegal()){
                Users.changeUsersDetails(user);
                Toast.makeText(this, "saved changes", Toast.LENGTH_SHORT).show();
                updateTheServerUsers();

            }
        }
    }


    public void backToMain(){
        String act = getIntent().getStringExtra("Activity");
        if (act.equals("none id")){
            Intent intent=new Intent(this,BooksActivity.class);
            startActivity(intent);
        }else{
            Intent intent=new Intent(this,PurchaseActivity.class);
            intent.putExtra("id",act);
            startActivity(intent);
        }
    }


    public boolean isPasswordlegal(){
        boolean isInt=false;
        boolean isCapital=false;
        String password= etUserPassword.getText().toString();
        for (int i=0;i<password.length();i++){
            if (!isInteger(password.charAt(i)) && !Character.isAlphabetic(password.charAt(i))){
                Toast.makeText(this, "CAN ONLY CONTAIN NUMBERS OR ENGLISH LETTERS", Toast.LENGTH_SHORT).show();

            }
            if (isInteger(password.charAt(i))){
                isInt=true;
            }
            if (Character.isUpperCase(password.charAt(i))){
                isCapital=true;
            }
        }
        if (password.length() >= 8 && isInt && isCapital){
            return true;
        }else if (!isInt){
            Toast.makeText(this, "SHOULD CONTAIN AT LEAST 1 NUMBER", Toast.LENGTH_SHORT).show();
            return false;
        }else if (!isCapital){
            Toast.makeText(this, "SHOULD CONTAIN AT LEAST 1 CAPITAL LETTER", Toast.LENGTH_SHORT).show();
            return false;
        }
        Toast.makeText(this, "SHOULD HAVE 8 OR MORE CHARACTERS", Toast.LENGTH_SHORT).show();
        return false;
    }


    public void updateTheServerUsers(){




        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();
                        //service.updateData();





                        RestApi restApi = new RestApi();
                        System.out.println(Users.getUsers().size() + " in the thread");
                        String lastId = User.currentUser.getUserID();
                        String bforeID = User.currentUser.getUserID();
                        String beforePassword = User.currentUser.getPassword();


                        if (!User.currentUser.getUserFirstName().equals(etUserName.getText().toString())){
                            /*String command =
                            restApi.sqlCommand(command);*/
                            //System.out.println("the command is " +command);
                            restApi.sqlCommand("update users set userFirstName=\""+ etUserName.getText().toString()+"\" where userID=\""+ User.currentUser.getUserID()+"\"");

                            User.currentUser.setUserFirstName(etUserName.getText().toString());
                        }
                        if (!User.currentUser.getUserLastName().equals(etFname.getText().toString())){
                            restApi.sqlCommand("update users set userLastName=\""+etFname.getText().toString()+"\" where userID=\""+ User.currentUser.getUserID()+"\"");
                            User.currentUser.setUserLastName(etFname.getText().toString());
                        }
                        if (!User.currentUser.getAddress().equals(etUserAddress.getText().toString())){
                            restApi.sqlCommand("update users set address=\""+ etUserAddress.getText().toString()+"\" where userID=\""+ User.currentUser.getUserID()+"\"");
                            User.currentUser.setAddress(etUserAddress.getText().toString());
                        }
                        if (!User.currentUser.getCity().equals(etUserCity.getText().toString())){
                            restApi.sqlCommand("update users set city=\""+ etUserCity.getText().toString()+"\" where userID=\""+ User.currentUser.getUserID()+"\"");
                            User.currentUser.setCity(etUserCity.getText().toString());
                        }
                        if (!User.currentUser.getPhoneNumber().equals(etUserPhoneNumber.getText().toString())){
                            restApi.sqlCommand("update users set phoneNumber=\""+ etUserPhoneNumber.getText().toString()+"\" where userID=\""+ User.currentUser.getUserID()+"\"");
                            User.currentUser.setPhoneNumber(etUserPhoneNumber.getText().toString());
                        }
                        if (!User.currentUser.getCreditNumber().equals(etCreditNumber.getText().toString())){
                            restApi.sqlCommand("update users set creditNumber=\""+etCreditNumber.getText().toString()+"\" where userID=\""+ User.currentUser.getUserID()+"\"");
                            User.currentUser.setCreditNumber(etCreditNumber.getText().toString());
                        }
                        if (!User.currentUser.getPassword().equals(etUserPassword.getText().toString())){
                            restApi.sqlCommand("update users set password=\""+ etUserPassword.getText().toString()+"\" where userID=\""+ User.currentUser.getUserID()+"\"");
                            User.currentUser.setPassword(etUserPassword.getText().toString());
                        }
                        if (!User.currentUser.getUserID().equals(etUserId.getText().toString())){
                            restApi.sqlCommand("update users set userID=\""+ etUserId.getText().toString()+"\" where userID=\""+ User.currentUser.getUserID()+"\"");
                            User.currentUser.setUserID(etUserId.getText().toString());

                        }
                        System.out.println(User.currentUser.getUserFirstName() + " asdawsdasasd");
                        Users.updateChanges(User.currentUser, lastId);
                        if (User.currentUser.getUserID().equals(bforeID)==false || User.currentUser.getPassword().equals(beforePassword)==false){
                            clearData();
                        }
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                backToMain();

                            }
                        });
                    }
                }


        ).start();






        //  Books.saveToJson(this);
    }

    public void clearData(){
        sharedPreferences= getSharedPreferences(LogInActivity.SHARED_PREFS, MODE_PRIVATE);
        editor=sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }
}