package com.example.projectrp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
/**
 * The class activity for the main page of the app
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnUp;
    Button btnIn;
    SeekBar seekBar;
    TextView tvLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initTextView();
        initSeekBar();
        runService();
        loading();
    }




    void initButton() {
        btnUp = findViewById(R.id.btnUp);
        btnIn = findViewById(R.id.btnIn);
        btnIn.setOnClickListener(this);
        btnUp.setOnClickListener(this);
    }

    void initTextView(){
        tvLoading=findViewById(R.id.tvLoading);
    }

    void initSeekBar(){
        seekBar=findViewById(R.id.seekBar);
        if (MyService.getFinished() == 4){
            seekBar.setVisibility(View.GONE);
            tvLoading.setVisibility(View.GONE);
            return;
        }
        seekBar.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                return true;
            }
        });
    }

    @Override
    public void onClick(View view) {
        if (view == btnIn) {
            Intent intent = new Intent(this, LogInActivity.class);
            startActivity(intent);
        } else if (view == btnUp) {
            Intent intent = new Intent(this, SignUpActivity.class);
            startActivity(intent);
        }
    }

    void runService() {
        startService(new Intent(this, MyService.class));
    }

    void loading() {
        new Thread(
                new Runnable() {
                    @Override
                    public void run() {


                        while (MyService.getFinished() != 4) {

                            try {
                                Thread.sleep(200);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }


                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    //Toast.makeText(MainActivity.this, "percent:"+, Toast.LENGTH_SHORT).show();
                                    seekBar.setProgress((int) ((MyService.getFinished()/(double)MyService.getTables())*100));
                                    if(MyService.getFinished() == 4){
                                        tvLoading.setVisibility(View.GONE);
                                        seekBar.setVisibility(View.GONE);
                                    }
                                }
                            });

                        }
                        initButton();

                    }
                }


        ).start();
    }
}