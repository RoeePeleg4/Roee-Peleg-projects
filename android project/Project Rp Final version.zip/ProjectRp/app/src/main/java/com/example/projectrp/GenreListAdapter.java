package com.example.projectrp;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;

import androidx.annotation.NonNull;

import java.util.List;
/**
 * The class of the ListAdapter for the filtering of the books
 */
public class GenreListAdapter extends ArrayAdapter {
    CheckBox cbGenre;
    Activity context;
    public GenreListAdapter(@NonNull Activity context, int resource, int textViewResourceId, @NonNull List objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);
        String genre = (String) getItem(position);
        cbGenre = view.findViewById(R.id.cbGenre);
        cbGenre.setText(genre);
        System.out.println("Hello World!");
        if (BooksActivity.isResetNow){
            Books.resetIsCheckedGenre();
            BooksActivity.isResetNow = false;
        }
        if (Books.getIsCheckedGenre().contains(cbGenre.getText())){
            cbGenre.setChecked(true);
        }else{
            cbGenre.setChecked(false);
        }
        cbGenre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                CheckBox checkBox = (CheckBox) view;


                if (view == checkBox){
                    if (checkBox.isChecked()){
                        Books.addToIsCheckedGenre((String) checkBox.getText());
                        System.out.println("hello world! 2 " + Books.getIsCheckedGenre().size());
                    }else{
                        Books.removeFromIsCheckedGenre((String) checkBox.getText());
                        System.out.println("hello world! 3 " + Books.getIsCheckedGenre().size());
                    }
                }

            }
        });


        return view;
    }
}
