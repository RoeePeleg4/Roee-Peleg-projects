package com.example.projectrp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;
/**
 * The class activity for the main page of the app
 */
public class ManagerActivity extends AppCompatActivity {
    public static boolean isSendSmsClicked;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);

        adptListView();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menupurchases, menu);
        //isSendSmsClicked = false;


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.send:
                /*ArrayList<Purchase> purchaseArrayList=Purchases.getPurchases();
                System.out.println(purchaseArrayList.size());
                //Toast.makeText(this, purchaseArrayList.size(), Toast.LENGTH_SHORT).show();
                for (int i=0;i<purchaseArrayList.size();i++){
                    if (purchaseArrayList.get(i).isSendSms()){
                        Costumer costumer=Costumers.getCostumerById(purchaseArrayList.get(i).getCostumerId());
                        if (purchaseArrayList.get(i).isDelivery()){
                            SendSms.sendSMS(costumer.getPhoneNumber(),"Hi " + costumer.getCostumerFirstName() + " " + costumer.getCostumerLastName() + "\nYour Order " + purchaseArrayList.get(i).getPurchaseId() + " is on it's way to your house!" , ManagerActivity.this);
                        }else{
                            SendSms.sendSMS(costumer.getPhoneNumber(), "Hi " + costumer.getCostumerFirstName() + " " + costumer.getCostumerLastName() + "\n thanks for picking up your order! " + purchaseArrayList.get(i).getPurchaseId(),ManagerActivity.this);
                        }
                        purchaseArrayList.remove(i);
                        i--;
                    }
                }
                System.out.println(Purchases.getPurchases().size() + " real");*/
//                ArrayList<Purchase> toSendSms = new ArrayList<Purchase>();

                updateTheServerPurchases();
                //ArrayList<Purchase> purchaseArrayList=Purchases.getPurchases();
                /*for (int i=0;i<toSendSms.size();i++){
                    Purchase purchase = toSendSms.get(i);
                    Costumer costumer=Costumers.getCostumerById(purchase.getCostumerId());

                }*/
                //isSendSmsClicked = true;

                //updateTheServerPurchases();
                //Purchases.clearCostumersToSendSms();
                break;
            case R.id.back:
                Intent intent=new Intent(this,MainManagerActivity.class);
                startActivity(intent);

        }
        return super.onOptionsItemSelected(item);
    }

    public void adptListView(){
        ListView lVContactList = findViewById(R.id.lvPurchases);
        //Books.getFromJson(this);

        ArrayList<Purchase> purchasesToShow = Purchases.filterByNotShipped();

        PurchaseListAdapter contactListAdapter = new PurchaseListAdapter(this, R.layout.purchases_list_view, R.id.tvUserDetails, purchasesToShow);
        lVContactList.setAdapter(contactListAdapter);
    }

    public void adptListView2(){
        ListView lVContactList = findViewById(R.id.lvPurchases);
        //Books.getFromJson(this);

        Purchases purchases =Purchases.getPurchases();
        updateTheServerPurchases();
        for (int i=0;i<purchases.size();i++){
            if (purchases.get(i).getIsShippingNow()){
                purchases.remove(i);
                i--;
            }
        }
        PurchaseListAdapter contactListAdapter = new PurchaseListAdapter(this, R.layout.purchases_list_view, R.id.tvUserDetails, purchases);
        lVContactList.setAdapter(contactListAdapter);
    }

    /*public void adptListView2(){
        ListView lVContactList = findViewById(R.id.lvPurchases);
        //Books.getFromJson(this);
        //
        ArrayList<Purchase> toSendSms = Purchases.getCostumersToSendSms();
        System.out.println(toSendSms.size() + " tytytyty");

        /*for (int i=0;i<toSendSms.size();i++){
            System.out.println(purchases.size() + " before");
            purchases.remove(toSendSms.get(i));
            System.out.println(purchases.size() + " after");
        }
        for (int i=0;i<toSendSms.size();i++){
            System.out.println(Purchases.getCostumersToSendSms().size() + " asdasd");
            Purchases.removePurchase(toSendSms.get(i));
        }
        Purchases purchases =Purchases.getPurchases();
        System.out.println(purchases.size() + " after * 2");
        PurchaseListAdapter contactListAdapter = new PurchaseListAdapter(this, R.layout.purchases_list_view, R.id.tvCostumerDetails, purchases);
        lVContactList.setAdapter(contactListAdapter);
        updateTheServerPurchases();

    }*/

    public void updateTheServerPurchases(){


        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();
                        //service.updateData();
                        String toSendSms = sendSms();

                        RestApi restApi = new RestApi();
                      //  Purchases.setPurchasesByClicked();
                      //  ArrayList<Purchase> purchases = Purchases.getPurchases();
                     //   System.out.println(purchases.size() + " hello world hi");
                        //System.out.println(toSendSms.size() + " hi tere");


                        System.out.println(Purchases.getPurchases().size() + " qweyqwey");
                        //restApi.saveFile("jsons/purchases.json",   Serialization.convertObjectToJson(Purchases.getPurchases()));
                        System.out.println(toSendSms);
                        restApi.sqlCommand(toSendSms);



                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                adptListView();
                            }
                        });
                    }
                }


        ).start();






        //  Books.saveToJson(this);
    }



    public String sendSms() {
        String toSendSms = "update purchases set shipped=\""+ true +"\" where ";
        Purchases purchases = Purchases.getPurchases();
        for (int g = 0; g < purchases.size(); g++) {
            if (purchases.get(g).getIsShippingNow()) {
                toSendSms += "purchaseId =\"" + purchases.get(g).getPurchaseId() + "\" or ";
                System.out.println("dwioawdas");
                purchases.get(g).setShipped(true);
                purchases.get(g).setShippingNow(false);
                User user = Users.getUserById(purchases.get(g).getUserId());
                if (purchases.get(g).isDelivery()) {
                    SendSms.sendSMS(user.getPhoneNumber(), "Hi " + user.getUserFirstName() + " " + user.getUserLastName() + "\nYour Order " + purchases.get(g).getPurchaseId() + " is on it's way to your house!", ManagerActivity.this);
                } else {
                    SendSms.sendSMS(user.getPhoneNumber(), "Hi " + user.getUserFirstName() + " " + user.getUserLastName() + "\nthanks for picking up your order! " + purchases.get(g).getPurchaseId(), ManagerActivity.this);
                }
                //toSendSms.add(purchases.get(g));
            }
        }
        return toSendSms.substring(0,toSendSms.length()-3);
    }
}
