package com.example.projectrp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
/**
 * The class activity to login into the app
 */
public class LogInActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnBackLog;
    Button btnLogIn;
    EditText etId;
    EditText etPassword;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        initButton();
        loadData();
        updateViews();

        btnLogIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view == btnLogIn){
                    findUser();
                }
            }
        });
    }

    public void findUser(){
        Context context = this;

        for (User c: Users.getUsers()){
            if (c.getUserID().equals(etId.getText().toString()) && c.getPassword().equals(etPassword.getText().toString())){
                saveData();
                Intent intent=new Intent(context,BooksActivity.class);
                User.currentUser =c;
                context.startActivity(intent);
                startActivity(intent);
                return;
            }
        }
        Toast.makeText(context, "Wrong password/Id", Toast.LENGTH_SHORT).show();
    }


    void initButton(){
     //   btnLogIn.setOnClickListener((View.OnClickListener) this);
        etId=findViewById(R.id.etId);
        etPassword=findViewById(R.id.etPassword);
        btnLogIn=findViewById(R.id.btnLogIn);
        btnBackLog=findViewById(R.id.btnBackLog);
        btnBackLog.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == btnBackLog){
            Intent intent=new Intent(this,MainActivity.class);
            startActivity(intent);
        }
    }


    public static final String SHARED_PREFS="sharedPrefs";
    public static final String TEXT="text";

    private String text;


    public void saveData(){
        sharedPreferences= getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        editor=sharedPreferences.edit();
        editor.putString(TEXT , etId.getText().toString());
        editor.apply();
    }
    public void loadData(){
        SharedPreferences sharedPreferences=getSharedPreferences(SHARED_PREFS,MODE_PRIVATE);
        text = sharedPreferences.getString(TEXT, "");

    }
    public void updateViews(){
        if (text.equals("") || text.equals(null)){
            return;
        }
        //RestApi restApi = new RestApi();
        User user = Users.getUserById(text);


        etId.setText(user.getUserID());
        etPassword.setText(user.getPassword());
    }
}