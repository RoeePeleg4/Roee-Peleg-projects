package com.example.projectrp;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.bumptech.glide.Glide;

import java.util.List;
/**
 * The class of the ListAdapter for the books purchase
 */
public class BookListAdapter extends ArrayAdapter{

    Context context;

    public BookListAdapter(@NonNull Context context, int resource, int textViewResourceId, @NonNull List objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);

        Book book = (Book) getItem(position);

        //ImageView ivPictureInPurchase= (ImageView) view.findViewById(R.id.ivPictureInPurchase);
        ImageView ivCart= (ImageView) view.findViewById(R.id.ivCart);
        ImageView ivBookPic = (ImageView) view.findViewById(R.id.ivBookPic);
        TextView tvBookName = (TextView) view.findViewById(R.id.tvBookName);
        TextView tvAutorName = (TextView) view.findViewById(R.id.tvAutorName);
        TextView tvDescription = (TextView) view.findViewById(R.id.tvDescription);
        TextView tvPrice = (TextView) view.findViewById(R.id.tvPrice);



        /*finding the coponents*/
	/*examples how to find it
        TextView tVname = (TextView) view.findViewById(R.id.tVname);
        TextView tVSurname = (TextView) view.findViewById(R.id.tVSurname);
        TextView tVphone = (TextView) view.findViewById(R.id.tVphone);
		*/
        if (book.getImageUrl().charAt(0)!='h'){
            Glide.with(context).load("https://app-server-sqllite.rvyplg.repl.co/images/" + book.getImageUrl() + ".jpg").into(ivBookPic);
        }else{
            Glide.with(context).load(book.getImageUrl()).into(ivBookPic);
        }
        //Glide.with(context).load(book.getUrl()).into(ivPictureInPurchase);
        tvBookName.setText(book.getName());
        tvAutorName.setText(book.getAuthor());
        tvDescription.setText(book.getDescription());
        tvPrice.setText(book.getPrice() + "₪");



        ivCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,PurchaseActivity.class);
                intent.putExtra("id",book.getId());
                context.startActivity(intent);
            }
        });


        /* set the infomartion of the item*/
	/* example
        tVname.setText(contact.getName());
        tVSurname.setText(contact.getSurname());
        tVphone.setText(contact.getPhone());
	*/

        return view;
    }
}