package com.example.projectrp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
/**
 * The class activity that allows signing up to the app
 */
public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    Button btnSignUp;
    EditText etID;
    EditText etFirstName;
    Button btnGoBackToMain;
    EditText etSecondName;
    EditText etCity;
    EditText etPhoneNumber;
    EditText etAddress;
    EditText etUserPassword;
    EditText etConfirmPassword;
    EditText etCredit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        initEditText();
        initButton();
    }
    void initButton(){
        btnGoBackToMain=findViewById(R.id.btnGoBackToMain);
        btnGoBackToMain.setOnClickListener(this);
        btnSignUp=findViewById(R.id.btnSignUp);
        btnSignUp.setOnClickListener(this);
    }
    void initEditText(){
        etID=findViewById(R.id.etID);
        etFirstName=findViewById(R.id.etFirstName);
        etSecondName=findViewById(R.id.etSecondName);
        etCity=findViewById(R.id.etCity);
        etPhoneNumber=findViewById(R.id.etPhoneNumber);
        etAddress =findViewById(R.id.etAddress);
        etUserPassword=findViewById(R.id.etUserPassword);
        etConfirmPassword=findViewById(R.id.etConfirmPassword);
        etCredit=findViewById(R.id.etCredit);
    }

    @Override
    public void onClick(View view) {
        if (view==btnGoBackToMain){
            Intent intent=new Intent(this,MainActivity.class);
            startActivity(intent);
        }
        else if (view == btnSignUp){
            if (!noEmptyEnters() || !isPasswordlegal() || !isIDLegal() || !isCreditValid(etCredit.getText().toString()) || !isPhoneNumberLegal(etPhoneNumber.getText().toString()) || !isValidForNames(etSecondName.getText().toString()) || !isValidForNames(etCity.getText().toString()) || !isValidForNames(etFirstName.getText().toString())){
                if (!noEmptyEnters()){
                    Toast.makeText(this, "There is an empty field", Toast.LENGTH_SHORT).show();
                }
                else if (!isCreditValid(etCredit.getText().toString())){
                    Toast.makeText(this, "CREDIT NUMBER CAN CONTAIN ONLY NUMBERS", Toast.LENGTH_SHORT).show();
                }
                else if (!isPhoneNumberLegal(etPhoneNumber.getText().toString())){
                    Toast.makeText(this, "PHONE NUMBER CAN CONTAIN ONLY NUMBERS, + AND -", Toast.LENGTH_SHORT).show();
                }
                else if (!isValidForNames(etFirstName.getText().toString())){
                    Toast.makeText(this, "NAME MUST CONTAIN ONLY ALPHABETHIC CHARACTERS, - AND SPACE", Toast.LENGTH_SHORT).show();
                }
                else if (!isValidForNames(etSecondName.getText().toString())){
                    Toast.makeText(this, "SECOND NAME NAME MUST CONTAIN ONLY ALPHABETHIC CHARACTERS, - AND SPACE", Toast.LENGTH_SHORT).show();
                }
                else if (!isValidForNames(etCity.getText().toString())){
                    Toast.makeText(this, "CITY MUST CONTAIN ONLY ALPHABETHIC CHARACTERS, - AND SPACE", Toast.LENGTH_SHORT).show();
                }
                else if (!isIDLegal()){
                    Toast.makeText(this, "Other user also have this ID", Toast.LENGTH_SHORT).show();
                }

            }else{
                User user =new User(etID.getText().toString(),etFirstName.getText().toString(),etCredit.getText().toString(), etAddress.getText().toString(),etSecondName.getText().toString(),etCity.getText().toString(),etUserPassword.getText().toString(),etPhoneNumber.getText().toString(),false);
                System.out.println(Users.getUsers().size() + " hi roee");
                updateTheServerUsers(user);
                clearData();
                Intent intent=new Intent(this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        }
    }

    public static boolean isCreditValid(String credit){
        for (int i=0;i<credit.length();i++){
            if (!(Character.isDigit(credit.charAt(i)) || credit.charAt(i)=='-')){
                return false;
            }
        }
        return true;
    }


    public static boolean isValidForNames(String str){
        for (int i=0;i<str.length();i++){
            if (!(!Character.isDigit(str.charAt(i)) || str.charAt(i)==' ' || str.charAt(i)=='-')){
                return false;
            }
        }
        return true;
    }

    public static boolean isInteger(char a){
        try{
            int u=Integer.parseInt(String.valueOf(a));
            return true;
        }catch(Exception e){
            return false;
        }
    }

    public static boolean isPhoneNumberLegal(String phoneNumber){
        for (int i=0;i<phoneNumber.length();i++){
            if (!(phoneNumber.charAt(i) =='+' || Character.isDigit(phoneNumber.charAt(i)) || phoneNumber.charAt(i) =='-')){
                return false;
            }
        }
        return true;
    }

    public boolean isPasswordlegal(){
        if (!etUserPassword.getText().toString().equals(etConfirmPassword.getText().toString())){
            Toast.makeText(this, "Passwords ain't match", Toast.LENGTH_SHORT).show();
            return false;
        }
        boolean isLowerCase=false;
        boolean isInt=false;
        boolean isCapital=false;
        String password=etUserPassword.getText().toString();
        for (int i=0;i<password.length();i++){
            if (!isInteger(password.charAt(i)) && !Character.isAlphabetic(password.charAt(i))){
                Toast.makeText(this, "CAN ONLY CONTAIN NUMBERS OR ENGLISH LETTERS", Toast.LENGTH_SHORT).show();

            }
            if (isInteger(password.charAt(i))){
                isInt=true;
            }
            if (Character.isUpperCase(password.charAt(i))){
                isCapital=true;
            }
            if (Character.isLowerCase(password.charAt(i))){
                isLowerCase=true;
            }
        }
        if (password.length() >= 8 && isInt && isCapital && isLowerCase){
            return true;
        }else if (!isInt){
            Toast.makeText(this, "SHOULD CONTAIN AT LEAST 1 NUMBER", Toast.LENGTH_SHORT).show();
            return false;
        }else if (!isCapital){
            Toast.makeText(this, "SHOULD CONTAIN AT LEAST 1 CAPITAL LETTER", Toast.LENGTH_SHORT).show();
            return false;
        }else if (!isLowerCase){
            Toast.makeText(this, "SHOULD CONTAIN AT LEAST 1 LOWER CASE LETTER", Toast.LENGTH_SHORT).show();
            return false;
        }
        Toast.makeText(this, "SHOULD HAVE 8 OR MORE CHARACTERS", Toast.LENGTH_SHORT).show();
        return false;
    }

    public boolean isIDLegal(){
        ArrayList<User> users = Users.getUsers();
        for (User user : users){
            if (user.getUserID().equals(etID.getText().toString())){
                return false;
            }
        }
        return true;
    }

    public boolean noEmptyEnters(){
        if (etID.getText().toString().equals("") || etFirstName.getText().toString().equals("") || etSecondName.getText().toString().equals("") || etCity.getText().toString().equals("") || etPhoneNumber.getText().toString().equals("") || etUserPassword.getText().toString().equals("") ||
                etConfirmPassword.getText().toString().equals("") ||  etCredit.getText().toString().equals("")){
            return false;
        }
        return true;
    }

    public void updateTheServerUsers(User user){




        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();
                        //service.updateData();



                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {


                            }
                        });

                        RestApi restApi = new RestApi();
                        Users.addUser(user);
                        System.out.println(Users.getUsers().size() + " in the thread");
                        restApi.sqlCommand("insert into users (userID, userFirstName, creditNumber, address, userLastName, city ,password , phoneNumber , isManager) values (\""+ user.getUserID()+"\",\""+ user.getUserFirstName()+"\",\""+ user.getCreditNumber()+"\",\""+ user.getAddress()+"\",\""+ user.getUserLastName()+"\",\""+ user.getCity()+"\",\""+ user.getPassword()+"\",\""+ user.getPhoneNumber()+"\",\""+false+"\")");


                    }
                }


        ).start();






        //  Books.saveToJson(this);
    }


    public void clearData(){
        sharedPreferences= getSharedPreferences(LogInActivity.SHARED_PREFS, MODE_PRIVATE);
        editor=sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }
}