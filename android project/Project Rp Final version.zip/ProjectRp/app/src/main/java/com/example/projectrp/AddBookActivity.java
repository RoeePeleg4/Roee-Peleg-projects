package com.example.projectrp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/**
 * The class activity that allows the manager add books to the store
 */

public class AddBookActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnGallery;
    Button btnSaveBook;
    EditText etBookName;
    EditText etAuthor;
    EditText etGenre;
    EditText etPrice;
    EditText etStock;
    EditText etBookDetail;
    EditText etSummery;
    ImageView ivBookImage;
    Bitmap currentImage;
    String id="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);
        init();
        PermissionExternalFile.askForExternalStoragePermission(this);
    }

    public void init(){
        etBookName = findViewById(R.id.etBookName);
        etAuthor = findViewById(R.id.etAuthor);
        etGenre = findViewById(R.id.etGenre);
        etPrice = findViewById(R.id.etPrice);
        etStock = findViewById(R.id.etStock);
        btnGallery = findViewById(R.id.btnGallery);
        etBookDetail = findViewById(R.id.etBookDetail);
        etSummery = findViewById(R.id.etSummery);
        btnSaveBook = findViewById(R.id.btnSaveBook);
        //ivBookImage = findViewById(R.id.ivBookImage);
        btnSaveBook.setOnClickListener(this);
        btnGallery.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == btnGallery){
            Intent intent = new Intent(Intent.ACTION_PICK , MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent , 0);
        }else if (view == btnSaveBook){
            if (etAuthor.getText().toString().equals("") || etBookDetail.getText().toString().equals("") || etBookName.getText().toString().equals("") || etGenre.getText().toString().equals("") || etPrice.getText().toString().equals("") || etStock.getText().toString().equals("") || etSummery.getText().toString().equals("")){
                Toast.makeText(this, "There is an empty field", Toast.LENGTH_SHORT).show();
                return;
            }
            int price;
            int stock;
            try{
                price = Integer.parseInt(etPrice.getText().toString());
                stock = Integer.parseInt(etStock.getText().toString());
            }
            catch (Exception e){
                Toast.makeText(this, "Stock and Price must be an integer", Toast.LENGTH_SHORT).show();
                return;
            }
            id = generateId();
            Book book = new Book(etBookName.getText().toString() , etAuthor.getText().toString() , price , etBookDetail.getText().toString() ,id , id, stock , etSummery.getText().toString() , etGenre.getText().toString());
            Books.addBookToBooks(book);
            updateTheServerBooks(book);
            finish();
            Intent intent=new Intent(this,MainManagerActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuback, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.backToMainMannger:
                Intent intent=new Intent(this,MainManagerActivity.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


    public static String generateId(){
        ArrayList<Book> books = Books.getBooks();
        Random rand = new Random();
        int rnd = rand.nextInt(9000) + 1000;
        for (int i=0;i< books.size();i++){
            if (books.get(i).getId().equals(String.valueOf(rnd))){
                generateId();
            }
        }
        return String.valueOf(rnd);
    }

    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data !=null){
            Uri selectedImage = data.getData();
            ivBookImage = findViewById(R.id.ivBookImage);
            ivBookImage.setImageURI(selectedImage);
        }
    }*/



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0) {
            if (resultCode == RESULT_OK) {
                Uri photoUri = data.getData();
                try {
                    currentImage = MediaStore.Images.Media.getBitmap(getContentResolver(), photoUri);
                    ImageView img = findViewById(R.id.ivBookImage);
                    img.setImageBitmap(currentImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }



    public void updateTheServerBooks(Book book){



        Context context = this;

        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();
                        //service.updateData();



                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {


                            }
                        });

                        RestApi restApi = new RestApi();
                        //System.out.println(R.id.ivBookImage + " ");

                        String strImage = BitMapConversions.getStringFromBitmap(currentImage);

                        System.out.println(Users.getUsers().size() + " in the thread");
                        //restApi.saveFile("jsons/books.json",   Serialization.convertObjectToJson(Books.getBooks()));
                        //String command = "insert into books (name, author, price, description, id, url, stock, fullDescription,genre) values (\""+book.getName()+"\",\""+book.getAuthor()+"\",\""+book.getPrice()+"\",\""+book.getDescription()+"\",\""+book.getId()+"\",\""+book.getImageUrl()+"\",\""+book.getStock()+"\",\""+book.getFullDescription()+"\",\""+book.getGenre()+"\")";
                        //System.out.println("command is " + "insert into books (name, author, price, description, id, imageUrl, stock, fullDescription,genre) values (\""+book.getName()+"\",\""+book.getAuthor()+"\",\""+book.getPrice()+"\",\""+book.getDescription()+"\",\""+book.getId()+"\",\""+book.getImageUrl()+"\",\""+book.getStock()+"\",\""+book.getFullDescription()+"\",\""+book.getGenre()+"\")");
                        restApi.sqlCommand("insert into books (name, author, price, description, id, imageUrl, stock, fullDescription,genre) values (\""+book.getName()+"\",\""+book.getAuthor()+"\",\""+book.getPrice()+"\",\""+book.getDescription()+"\",\""+book.getId()+"\",\""+book.getImageUrl()+"\",\""+book.getStock()+"\",\""+book.getFullDescription()+"\",\""+book.getGenre()+"\")");
                        restApi.savePhoto(strImage, id);


                    }
                }


        ).start();






        //  Books.saveToJson(this);
    }
}