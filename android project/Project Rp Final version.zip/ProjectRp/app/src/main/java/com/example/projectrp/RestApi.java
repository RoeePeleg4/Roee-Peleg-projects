package com.example.projectrp;
/**
 * The class of the restApi of the app
 */
public class RestApi {

    ServerPostCommunication serverPostCommunication = new ServerPostCommunication();


    /*public String privateSqlCommand(String sqlCommand)
    {
        return  serverPostCommunication.doInBackground("function=privateSqlCommand", "sqlCommand="+sqlCommand);
    }*/


    public String sqlCommand(String sqlCommand)
    {
        return  serverPostCommunication.doInBackground("function=sqlCommand", "sqlCommand="+sqlCommand);
    }
    public String twoSqlCommand(String sqlCommand)
    {
        return  serverPostCommunication.doInBackground("function=twoSqlCommand", "sqlCommand="+sqlCommand);
    }


    /*public String showFile(String path)
    {


        return  serverPostCommunication.doInBackground("function=showFile", "path="+path);
    }


    public  void saveFile(String path,String data)
    {

        serverPostCommunication.doInBackground("function=saveFile", "path="+path,"txt="+data);
    }*/


    public void savePhoto(String photoText,String photoName)
    {

        serverPostCommunication.doInBackground("function=savePhoto", "photoText="+photoText,"photoName="+photoName );

    }

    public String getCodeUpdate() {
        return serverPostCommunication.doInBackground("function=getCodeUpdate");
    }
}

