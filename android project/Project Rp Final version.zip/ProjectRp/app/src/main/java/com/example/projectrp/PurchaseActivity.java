package com.example.projectrp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.concurrent.CountDownLatch;
/**
 * The class activity of the book purchase page
 */
public class PurchaseActivity extends AppCompatActivity implements View.OnClickListener {
    TextView bookIdToUse;
    Button btnBack;
    TextView tvStock;
    ImageView ivHeart;
    ImageView ivPicInPurchase;
    TextView tvFullDescription;
    TextView tvPricePurchase;
    Button btnBuy;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    PurchaseDialog purchaseDialog;

    String id="";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase);
        initTextView();
        initImageView();
        initButton();
        findBookId();
        addIdToPage();

        showLikedByUser();
        initActivity();




        ivHeart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageView img=(ImageView) view;
                likeDislike(img);
            }
        });


    }

    public void addIdToPage(){
        if (User.currentUser.isManager()) {
            Book book = Book.findBookById(id);
            bookIdToUse.setText("  book id: " + book.getId());
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        if (User.currentUser.isManager()){
            inflater.inflate(R.menu.menumanagerpur, menu);
        }
        else{
            inflater.inflate(R.menu.menupur, menu);
        }

        return true;
    }


    public void findBookId()
    {
         id = getIntent().getStringExtra("id");

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logoutManagerPur:
            case R.id.logoutRegularPur:
                User.currentUser =null;
                clearData();
                Intent intent=new Intent(this,MainActivity.class);
                startActivity(intent);
                break;

            case R.id.showDetailsManagerPur:
            case R.id.showDetailsRegularPur:
                Book book= Book.findBookById(id);
                Intent intent2=new Intent(this,DetailsActivity.class);
                intent2.putExtra("Activity",book.getId());
                startActivity(intent2);
                break;
            case R.id.mangerLogInPur:
                Intent intent3=new Intent(this,MainManagerActivity.class);
                intent3.putExtra("id from last page",id);
                startActivity(intent3);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    public void likeDislike(ImageView img){
        if (!LikeByUsers.isUserLiked(User.currentUser.getUserID() , id)){




            new Thread(
                    new Runnable() {
                        @Override
                        public void run() {
                            MyService service = new MyService();



                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    img. setImageResource(R.drawable.ic_baseline_favorite_24);

                                }
                            });
                            Book book = Book.findBookById(id);

                            RestApi restApi = new RestApi();
                            restApi.sqlCommand("insert into likeByUsers (bookId, userId) values (\""+id+"\",\""+ User.currentUser.getUserID()+"\")");
                            LikeByUser likeByUser = new LikeByUser(id , User.currentUser.getUserID());
                            LikeByUsers.getLikeByUsers().add(likeByUser);


                        }
                    }


            ).start();







          //  Books.saveToJson(this);
        }
        /*else if (!Book.isUserLike(Book.findBookById(id))){


            new Thread(
                    new Runnable() {
                        @Override
                        public void run() {
                            MyService service = new MyService();
                            service.updateData();



                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    img. setImageResource(R.drawable.ic_baseline_favorite_24);

                                }
                            });
                            Book book = Book.findBookById(id);

                            RestApi restApi = new RestApi();
                            restApi.saveFile("jsons/books.json",   Serialization.convertObjectToJson(Books.getBooks()));


                        }
                    }


            ).start();




            //Books.saveToJson(this);

        }*/else{

            new Thread(
                    new Runnable() {
                        @Override
                        public void run() {
                            MyService service = new MyService();



                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {

                                    img. setImageResource(R.drawable.ic_baseline_favorite_border_24);

                                }
                            });
                            //Book book = Book.findBookById(id);
                            //removeLike(book);
                            RestApi restApi = new RestApi();
                            restApi.sqlCommand("DELETE FROM likeByUsers WHERE userId =\""+ User.currentUser.getUserID()+"\" AND bookId =\""+id+"\";");
                            LikeByUser likeByUser = new LikeByUser(id , User.currentUser.getUserID());
                            LikeByUsers.removeFromLikeByUsers(likeByUser);


                        }
                    }


            ).start();



            //Books.saveToJson(this);
            //book.setLove(false);
        }
    }



    public void showLikedByUser(){
        ImageView img=ivHeart;
        if (LikeByUsers.isUserLiked(User.currentUser.getUserID() , id)){
            img.setImageResource(R.drawable.ic_baseline_favorite_24);
            //Books.saveToJson(this); // check it again! toto
        }
    }
    public void initActivity(){
        Book book = Book.findBookById(id);
        if (book.getImageUrl().charAt(0)!='h'){
            Glide.with(this).load("https://app-server-sqllite.rvyplg.repl.co/images/" + book.getImageUrl() + ".jpg").into(ivPicInPurchase);
        }else{
            Glide.with(this).load(book.getImageUrl()).into(ivPicInPurchase);
        }
        //Glide.with(this).load(book.getImageUrl()).into(ivPicInPurchase);
        tvFullDescription.setText(book.getFullDescription());
        tvPricePurchase.setText("price: " + book.getPrice() + " ₪");
        tvStock.setText("There are " + book.getStock() + " books left in the store");
    }



    public void initTextView(){
        bookIdToUse = findViewById(R.id.bookIdToUse);
        tvStock=findViewById(R.id.tvStock);
        tvPricePurchase=findViewById(R.id.tvPricePurchase);
        tvFullDescription=findViewById(R.id.tvFullDescription);
        tvFullDescription.setMovementMethod(new ScrollingMovementMethod());
    }
    public void initImageView(){
        ivHeart=findViewById(R.id.ivHeart);
        ivPicInPurchase=findViewById(R.id.ivPicInPurchase);
    }

    public void initButton(){
        btnBuy=findViewById(R.id.btnBuy);
        btnBuy.setOnClickListener(this);
        btnBack=findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);
    }

    /*public Book findBookById(){

        Books books = Books.getBooks();

        Book book=findBookById(id);
        //books.get(0).addBookToList("329193858"); //not for a long time!
        return book;
    }*/

    @Override
    public void onClick(View view) {
        CountDownLatch countDownLatch=new CountDownLatch(2);
        if (view == btnBack){
            Intent intent=new Intent(this,BooksActivity.class);
            startActivity(intent);
        }
        else if (view == btnBuy){
            System.out.println("is here?");
            Book book = Book.findBookById(id);
            if(book.getStock()==0){
                Toast.makeText(this, "Out Of Stock", Toast.LENGTH_SHORT).show();
                return;
            }
            openDialog();

            //if (!PurchaseDialog.isPurchased()){

            //}
        }
    }

    public void openDialog(){
        Book book = Book.findBookById(id);
        Book.currentBookOnDialog=Book.findBookById(id);
        purchaseDialog = new PurchaseDialog(this);
        purchaseDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                if (PurchaseDialog.isPurchased()){
                    book.decreaseStock();
                    initActivity();
                    //updateTheServerBooks();
                }
            }
        });
        purchaseDialog.show();

    }



    public void clearData(){
        sharedPreferences= getSharedPreferences(LogInActivity.SHARED_PREFS, MODE_PRIVATE);
        editor=sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }
    public void updateTheServerBooks(){


int x=3;

        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();
                        //service.updateData();





                        RestApi restApi = new RestApi();

                        Book book = Book.findBookById(id);
                        book.decreaseStock();
                        System.out.println(Purchases.getPurchases().size() + " in the thread " + book.getStock());
                        //restApi.saveFile("jsons/books.json",   Serialization.convertObjectToJson(Books.getBooks()));

                        try {
                            Thread.sleep(2000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        restApi.sqlCommand("update books set stock=\""+ book.getStock()+"\" where id=\""+book.getId()+"\"");

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                            }
                        });
                    }
                }


        ).start();






        //  Books.saveToJson(this);
    }

    /*public void updateTheServerPurchases(Purchase purchase){




        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();
                        service.updateData();



                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {


                            }
                        });

                        RestApi restApi = new RestApi();
                        Purchases.addPurchase(purchase);
                        System.out.println(Purchases.getPurchases().size() + " in the thread");
                        restApi.saveFile("jsons/purchases.json",   Serialization.convertObjectToJson(Purchases.getPurchases()));


                    }

                    private void runOnUiThread(Runnable runnable) {

                    }
                }


        ).start();






        //  Books.saveToJson(this);
    }*/
}