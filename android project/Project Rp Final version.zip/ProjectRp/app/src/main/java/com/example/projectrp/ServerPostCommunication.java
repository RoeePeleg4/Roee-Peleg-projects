package com.example.projectrp;

import android.os.AsyncTask;
import android.os.StrictMode;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
/**
 * The class that allows the app to connect to the server
 */

public class ServerPostCommunication extends AsyncTask<String, String, String> {

    private static final String URL = "https://App-server-sqllite.rvyplg.repl.co";

    private static HttpURLConnection con;


    public ServerPostCommunication() {
    }

    /*@Override
    protected void onPreExecute() {
        super.onPreExecute();
    }*/


    //request from server and getting the response (Json). REST API
    @Override
    protected  String doInBackground(String... params) {

        try {


            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                    .permitAll().build();
            StrictMode.setThreadPolicy(policy);


            String url = URL;

            String urlParameters = params[0];

            for (int i = 1; i < params.length; i++) {
                urlParameters += "&&" + params[i];
            }

            byte[] postData = urlParameters.getBytes(StandardCharsets.UTF_8);


            try {

                URL myurl = new URL(url);
                con = (HttpURLConnection) myurl.openConnection();


                con.setDoOutput(true);
                con.setRequestMethod("POST");
                con.setRequestProperty("User-Agent", "Java client");
                con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

                try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {

                    wr.write(postData);
                }


                StringBuilder content;


                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(con.getInputStream()))) {


                    String line;
                    content = new StringBuilder();

                    while ((line = br.readLine()) != null) {
                        content.append(line);
                        content.append(System.lineSeparator());
                    }


                    String adjusted = content.toString().replaceAll("(?m)^[ \t]*\r?\n", "");

                    System.out.println(adjusted);

                    return adjusted;
                }


            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {

                con.disconnect();
            }

            return "Hhhh";

        }
        catch (Exception e)
        {

        }

        return "hhh";
    }
}
