package com.example.projectrp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
/**
 * The class to give and check for sms permission
 */

/*
dont forget to add permission in manifest!!

<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />

 */

public class PermissionExternalFile {

    public final static int MY_PERMISSIONS_REQUEST_EXTERNAL_STRORAGE = 1;


    public static boolean hasExternalStoragePermission(Activity activity) {


        return (ContextCompat.checkSelfPermission(activity, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED);

    }

    public static void askForExternalStoragePermission(Activity activity) {
        if ( ! hasExternalStoragePermission(activity)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(activity,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        MY_PERMISSIONS_REQUEST_EXTERNAL_STRORAGE);
            }
        }
    }



    /*public static void askPermission(Activity activity) {
        askForPermission(activity);


    }*/
}
