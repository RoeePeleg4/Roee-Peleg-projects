package com.example.projectrp;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;
/**
 * The class of the ListAdapter to send sms to users by purchase
 */
public class PurchaseListAdapter extends ArrayAdapter {
    static int PERMISSION_CODE = 100;

    Activity context;

    public PurchaseListAdapter(@NonNull Activity context, int resource, int textViewResourceId, @NonNull List objects) {
        super(context, resource, textViewResourceId, objects);
        this.context = context;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = super.getView(position, convertView, parent);

        Purchase purchase = (Purchase) getItem(position);
        Book book = Book.findBookById(purchase.getBookId());
        User user = Users.getUserById(purchase.getUserId());
        ImageView ivCall = (ImageView) view.findViewById(R.id.ivCall);

        CheckBox cBisShipped = (CheckBox) view.findViewById(R.id.CBisShipped);
        cBisShipped.setChecked(purchase.getIsShippingNow());


        TextView tvUserDetails = (TextView) view.findViewById(R.id.tvUserDetails);
        TextView tvPricePur = (TextView) view.findViewById(R.id.tvPricePur);
        //ImageView ivPictureInPurchase= (ImageView) view.findViewById(R.id.ivPictureInPurchase);
        TextView tvBookDetails = (TextView) view.findViewById(R.id.tvBookDetails);
        tvUserDetails.setText("ID: " + purchase.getUserId() + "\n" + user.getUserFirstName() + " " + user.getUserLastName() + "\n" + "city: " + user.getCity() + "\n" + "address: " + user.getAddress() + "\n");
        tvPricePur.setText("" + purchase.getPrice());
        tvBookDetails.setText("id: " + book.getId() + "\n" + "name: " + book.getName());


        cBisShipped.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                purchase.setShippingNow(cBisShipped.isChecked());
                System.out.println(purchase.getIsShippingNow() + "dasdasdsdaasd");

            }
        });

        ivCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view == ivCall) {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {

                        ActivityCompat.requestPermissions(context, new String[]{Manifest.permission.CALL_PHONE}, PERMISSION_CODE);
                    }
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse("tel:" + user.getPhoneNumber()));//change the number
                    context.startActivity(callIntent);
                }
            }
        });



        /*ivCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context,PurchaseActivity.class);
                intent.putExtra("id",book.getId());
                context.startActivity(intent);
            }
        });/


         */
        /* set the infomartion of the item*/
	/* example
        tVname.setText(contact.getName());
        tVSurname.setText(contact.getSurname());
        tVphone.setText(contact.getPhone());
	*/

        return view;
    }
}