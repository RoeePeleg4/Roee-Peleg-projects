package com.example.projectrp;

import android.content.Context;

import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
/**
 * The class that converts json to object
 */

public class Serialization {

    /*public static <T> String convertObjectToJson(T object) {

        Gson gson = new Gson();
        return gson.toJson(object);

    }





    public static <T> T convertRawJsonToObject(Class<T> clas,int resource, Context context) {


        Gson gson = new Gson();

        return gson.fromJson(readJsonFile(resource,context), clas);

    }*/


    public static <T> T convertStringJsonToObject(Class<T> clas,String json) {


        Gson gson = new Gson();

        return gson.fromJson(json, clas);

    }


    /*private static String readJsonFile(int resource, Context context) {

        InputStream in = context.getResources().openRawResource(resource);
        String str = "";
        try {
            byte[] buffer = new byte[in.available()];
            in.read(buffer);
            str = new String(buffer, StandardCharsets.UTF_8);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }*/


}