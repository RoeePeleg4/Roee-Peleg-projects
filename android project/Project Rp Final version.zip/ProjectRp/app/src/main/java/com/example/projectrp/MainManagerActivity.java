package com.example.projectrp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
/**
 * The class activity to send sms to the users
 */
public class MainManagerActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnSet;
    Button btnPurchases;
    Button btnAddBook;
    Button btnUpdateStock;
    Button btnGetOutOfMannger;
    TextView tvIncome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_manager);
        initButton();
        initTv();
    }

    public void initButton(){
        btnGetOutOfMannger = findViewById(R.id.btnGetOutOfMannger);
        btnUpdateStock=findViewById(R.id.btnUpdateStock);
        btnAddBook=findViewById(R.id.btnAddBook);
        btnSet=findViewById(R.id.btnSet);
        btnPurchases=findViewById(R.id.btnPurchases);
        btnGetOutOfMannger.setOnClickListener(this);
        btnUpdateStock.setOnClickListener(this);
        btnSet.setOnClickListener(this);
        btnAddBook.setOnClickListener(this);
        btnPurchases.setOnClickListener(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void initTv(){
        tvIncome=findViewById(R.id.tvIncome);
        double money = getIncome();
        tvIncome.setText("The Income since the start of the month is " + money + "₪");
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public double getIncome(){
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDateTime date = LocalDateTime.now();
        String month=dtf1.format(date).substring(0,8);
        double totalMoney=0;
        for (int i=0;i<Purchases.getPurchases().size();i++){
            if (Purchases.getPurchases().get(i).getDate().substring(0,8).equals(month)){
                totalMoney+=Purchases.getPurchases().get(i).getPrice();
            }
        }
        return totalMoney;
    }

    @Override
    public void onClick(View view) {
        if (view == btnSet){
            Intent intent=new Intent(this,AddToManagerActivity.class);
            startActivity(intent);
        }else if (view == btnPurchases){
            Intent intent2=new Intent(this,ManagerActivity.class);
            startActivity(intent2);
        }else if (view == btnAddBook){
            Intent intent3=new Intent(this,AddBookActivity.class);
            startActivity(intent3);
        }else if (view == btnUpdateStock){
            Intent intent4=new Intent(this, UpdateBooksDetailsActivity.class);
            startActivity(intent4);
        }else if (view == btnGetOutOfMannger){
            String id = getIntent().getStringExtra("id from last page");
            if (id!=null){
                Intent intent6=new Intent(this,PurchaseActivity.class);
                intent6.putExtra("id",id);
                startActivity(intent6);
            }else{
                Intent intent5=new Intent(this,BooksActivity.class);
                startActivity(intent5);
            }
        }
    }
}