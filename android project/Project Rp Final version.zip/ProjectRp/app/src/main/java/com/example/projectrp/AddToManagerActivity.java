package com.example.projectrp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
/**
 * The class activity that allows the manager change the manager Permissions
 */
public class AddToManagerActivity extends AppCompatActivity implements View.OnClickListener {
    //TextView tvPersonDetails;
    EditText etIDToAdd;
    Button btnSetAsManager;
    Button btnRemove;
    Button btnShowDeatails;
    Button btnClear;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_manager);
        init();
    }
    public void init(){
        //tvPersonDetails=findViewById(R.id.tvPersonDetails);
        btnSetAsManager=findViewById(R.id.btnSetAsManager);
        btnRemove=findViewById(R.id.btnRemove);
        btnShowDeatails=findViewById(R.id.btnShowDeatails);
        btnClear=findViewById(R.id.btnClear);
        etIDToAdd=findViewById(R.id.etIDToAdd);
        btnSetAsManager.setOnClickListener(this);
        btnRemove.setOnClickListener(this);
        btnShowDeatails.setOnClickListener(this);
        btnClear.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuback, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.backToMainMannger:
                Intent intent=new Intent(this,MainManagerActivity.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        if (view == btnSetAsManager){
            String idPerson = etIDToAdd.getText().toString();
            User user = Users.getUserById(idPerson);
            if (user !=null){
                if (User.currentUser.getUserID().equals(idPerson)){
                    Toast.makeText(this, "You are a manager", Toast.LENGTH_SHORT).show();
                }
                else if (user.isManager()){
                    Toast.makeText(this, "is already manager", Toast.LENGTH_SHORT).show();
                }else{
                    Users.setUserAsMannager(idPerson);
                    updateTheServerUsers(true);
                }
            }else{
                Toast.makeText(this, "Person was not found", Toast.LENGTH_SHORT).show();
            }
        }
        else if (view == btnRemove){
            String idPerson = etIDToAdd.getText().toString();
            User user = Users.getUserById(idPerson);
            if (user !=null){
                if (User.currentUser.getUserID().equals(idPerson)){
                    Toast.makeText(this, "You can't unmannager yourself", Toast.LENGTH_SHORT).show();
                }
                else if (!user.isManager()){
                    Toast.makeText(this, "is already not mannager", Toast.LENGTH_SHORT).show();
                }else{
                    Users.setUserAsNotMannager(idPerson);
                    updateTheServerUsers(false);
                }
            }else{
                Toast.makeText(this, "Person was not found", Toast.LENGTH_SHORT).show();
            }
        }
        else if (view == btnClear){
            etIDToAdd.setText("");
            //tvPersonDetails.setText("");
        }
        else if (view == btnShowDeatails){
            String idPerson = etIDToAdd.getText().toString();
            User user = Users.getUserById(idPerson);
            if (user !=null){
                Toast.makeText(this, user.getUserFirstName() + " " + user.getUserLastName(), Toast.LENGTH_SHORT).show();
                //tvPersonDetails.setText(user.getUserFirstName() + " " + user.getUserLastName());
            }else{
                Toast.makeText(this, "Person was not found", Toast.LENGTH_SHORT).show();
            }

        }
    }


    public void updateTheServerUsers(boolean setAsIsMannger){




        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();
                        //service.updateData();



                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {


                            }
                        });

                        RestApi restApi = new RestApi();
                        System.out.println(Users.getUsers().size() + " in the thread");
                        restApi.sqlCommand("update users set isManager=\""+setAsIsMannger+"\" where userID=\""+etIDToAdd.getText().toString()+"\"");

                    }
                }


        ).start();






        //  Books.saveToJson(this);
    }
}