package com.example.projectrp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
/**
 * The class activity that lets the user see all of the books
 */
public class BooksActivity extends AppCompatActivity{
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    public static String textToSearch = "";
    static boolean isResetNow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Toast.makeText(this, Purchases.getPurchases().get(0).getBookId(), Toast.LENGTH_SHORT).show();
        isResetNow=false;
        setContentView(R.layout.activity_books);
        adptListViewBySomething("");
        //Toast.makeText(this, books.size()+" ", Toast.LENGTH_SHORT).show();

        //connect contacts to ListView by Adapter

        //adptListViewBySomething("prince");

        //adptListViewBySomething("as");


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        if (User.currentUser.isManager()){
            inflater.inflate(R.menu.menumanagerbooks, menu);
        }else{
            inflater.inflate(R.menu.menubooks, menu);
        }
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        if (null != searchView) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setIconifiedByDefault(false);
        }

        SearchView.OnQueryTextListener queryTextListener = new SearchView.OnQueryTextListener() {
            public boolean onQueryTextChange(String newText) {
                //Toast.makeText(BooksActivity.this, "no", Toast.LENGTH_SHORT).show();
                textToSearch = newText;
                adptListViewBySomething(newText);
                // this is your adapter that will be filtered
                return true;
            }

            public boolean onQueryTextSubmit(String query) {
                //Here u can get the value "query" which is entered in the search box.
                //Toast.makeText(BooksActivity.this, "yes", Toast.LENGTH_SHORT).show();
                //adptListViewBySomething(query);
                return false;
            }
        };
        searchView.setOnQueryTextListener(queryTextListener);

        return super.onCreateOptionsMenu(menu);

        /*MenuItem.OnActionExpandListener onActionExpandListener=new MenuItem.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem menuItem) {
                Toast.makeText(BooksActivity.this, "Search is expended", Toast.LENGTH_SHORT).show();
                return false;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem menuItem) {
                Toast.makeText(BooksActivity.this, "Search is collapsed", Toast.LENGTH_SHORT).show();
                return false;
            }
        };
        //menu.findItem(R.id.search).setOnActionExpandListener(onActionExpandListener);
        //SearchView searchView=(SearchView) menu.findItem(R.id.search).getActionView();
        //searchView.setQueryHint("Search data Hear...");*/
        //return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logoutRegularuserBooks:
            case R.id.logoutManagerBooks:
                User.currentUser =null;
                clearData();
                Intent intent=new Intent(this,MainActivity.class);
                startActivity(intent);
                break;
            case R.id.showDetailsManagerBooks:
            case R.id.showDetailsRegularuserBooks:
                Intent intent2=new Intent(this,DetailsActivity.class);
                intent2.putExtra("Activity","none id");
                startActivity(intent2);
                break;
            case R.id.managerLoginBooks:
                Intent intent3=new Intent(this,MainManagerActivity.class);
                startActivity(intent3);
                break;
            case R.id.filterManager:
            case R.id.filter:
                openDialog();

        }
        return super.onOptionsItemSelected(item);
    }

    public void openDialog(){

        GenreDialog genreDialog = new GenreDialog(this);

        /*genreDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                if (PurchaseDialog.isPurchased()){
                }
            }
        });*/


        genreDialog.show();

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(genreDialog.getWindow().getAttributes());

        // setting width to 90% of display
        layoutParams.width = (int) (displayMetrics.widthPixels * 0.9f);

        // setting height to 90% of display
        layoutParams.height = (int) (displayMetrics.heightPixels * 0.8f);
        genreDialog.getWindow().setAttributes(layoutParams);

        genreDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                if (GenreDialog.isFinished == true){
                    System.out.println(Books.getIsCheckedGenre().size() + " james");
                    adptListViewBySomething(textToSearch);
                }
            }
        });

    }

    public void adptListView(){
        ListView lVContactList = findViewById(R.id.lVBooks);
        //Books.getFromJson(this);

        Books books =Books.getBooks();
        BookListAdapter contactListAdapter = new BookListAdapter(this, R.layout.cutsom_item_list_view, R.id.tvBookName, books);
        lVContactList.setAdapter(contactListAdapter);

    }

    /*public void removeFromList(Books books, String something, String isIn){
        if (isIn.contains(something)){
            books.remove()
        }
    }*/

    public void adptListViewBySomething(String somthing){
        if (isResetNow){
            adptListView();
            return;
        }
        ListView lVContactList = findViewById(R.id.lVBooks);
        //Books.getFromJson(this);
        ArrayList <Book> clone=cloneList();
        boolean emptyArray = false;
        if (Books.getIsCheckedGenre().size()==0){
            emptyArray = true;
        }
        for (int i=0;i<clone.size();i++){
            boolean userLiked = LikeByUsers.isUserLiked(User.currentUser.getUserID(), clone.get(i).getId());
            if (!emptyArray){
                if (LikeByUsers.showLiked){
                    if ((!(clone.get(i).getAuthor().toLowerCase().contains(somthing.toLowerCase()) || clone.get(i).getName().toLowerCase().contains(somthing.toLowerCase()))) || !Books.getIsCheckedGenre().contains(clone.get(i).getGenre()) || !userLiked){
                        clone.remove(i);
                        i--;
                    }
                }else {
                    if ((!(clone.get(i).getAuthor().toLowerCase().contains(somthing.toLowerCase()) || clone.get(i).getName().toLowerCase().contains(somthing.toLowerCase()))) || !Books.getIsCheckedGenre().contains(clone.get(i).getGenre())){
                        clone.remove(i);
                        i--;
                    }
                }

            }else{
                if (LikeByUsers.showLiked){
                    if ((!(clone.get(i).getAuthor().toLowerCase().contains(somthing.toLowerCase()) || clone.get(i).getName().toLowerCase().contains(somthing.toLowerCase()))) || !userLiked){
                        clone.remove(i);
                        i--;
                    }
                }else{
                    if ((!(clone.get(i).getAuthor().toLowerCase().contains(somthing.toLowerCase()) || clone.get(i).getName().toLowerCase().contains(somthing.toLowerCase())))){
                        clone.remove(i);
                        i--;
                    }
                }

            }
        }
        BookListAdapter contactListAdapter = new BookListAdapter(this, R.layout.cutsom_item_list_view, R.id.tvBookName, clone);
        lVContactList.setAdapter(contactListAdapter);
    }

    public ArrayList<Book> cloneList(){
        ArrayList<Book> cloneList=new ArrayList<Book>();
        for (Book book:Books.getBooks()){
            cloneList.add(book);
        }
        return cloneList;
    }
    public void clearData(){
        sharedPreferences= getSharedPreferences(LogInActivity.SHARED_PREFS, MODE_PRIVATE);
        editor=sharedPreferences.edit();
        editor.clear();
        editor.commit();
    }

}