package com.example.projectrp;

import java.util.ArrayList;
/**
 * The class of the object of multiple likeByUser
 */
public class LikeByUsers extends ArrayList<LikeByUser> {
    private static LikeByUsers likeByUsers = new LikeByUsers();

    public static boolean showLiked = false;

    public static LikeByUsers getLikeByUsers() {
        return likeByUsers;
    }

    public static boolean isUserLiked(String userId , String bookId){
        for (int i=0;i<likeByUsers.size();i++){
            if (likeByUsers.get(i).getBookId().equals(bookId) && likeByUsers.get(i).getUserById().equals(userId)){
                return true;
            }
        }
        return false;
    }

    public static void removeFromLikeByUsers(LikeByUser likeByUser){
        String bookId = likeByUser.getBookId();
        String userId = likeByUser.getUserById();
        for (int i=0;i<likeByUsers.size();i++){
            if (likeByUsers.get(i).getBookId().equals(bookId) && likeByUsers.get(i).getUserById().equals(userId)){
                likeByUsers.remove(i);
                i--;
            }
        }
    }

    public static void setLikeByUsers(LikeByUsers likeByUsers) {
        LikeByUsers.likeByUsers = likeByUsers;
    }
}
