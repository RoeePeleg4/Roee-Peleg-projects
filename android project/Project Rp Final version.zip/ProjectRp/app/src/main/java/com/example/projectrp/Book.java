package com.example.projectrp;
import android.widget.Toast;

import java.util.ArrayList;
/**
 * The class of the Book object
 */
class Book{
    public static Book currentBookOnDialog;
    //private ArrayList<String> likesListUsers;
    private int stock;
    private String fullDescription;
    private String author;
    private String name;
    private String description;
    private String id;
    private double price;
    private String imageUrl;
    private String genre;


    public Book(String name, String author, double price, String description, String id, String url, int stock, String fullDescription,String genre){
        this.stock=stock;
        this.fullDescription=fullDescription;
        this.author=author;
        this.price=price;
        this.name=name;
        this.description =description;
        this.id=id;
        this.imageUrl =url;
        //this.likesListUsers =new ArrayList<String>();
        this.genre=genre;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getGenre() {
        return genre;
    }

    /*public void addCostumerIdToLikes(String id){
        if(likesListUsers ==null)
            this.likesListUsers =new ArrayList<String>();
        this.likesListUsers.add(id);
    }*/

    public void setStock(int stock) {
        this.stock = stock;
    }

    /*public ArrayList<String> getLikesList(){
        ArrayList<String> str =new ArrayList<String>();
        str.add("asd");
        return str;
        //return this.likesListUsers;
    }*/

    /*public void removeFromLikesList(int i) {
        return;
        //this.likesListUsers.remove(i);
    }*/
    public int getStock() {
        return stock;
    }

    public String getFullDescription() {
        return fullDescription;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getDescription() {
        return description;
    }

    public String getId() {
        return id;
    }

    public String getName(){
        return this.name;
    }

    public String getAuthor(){
        return this.author;
    }

    public double getPrice(){
        return this.price;
    }

    public void decreaseStock() {
        this.stock = this.stock-1;
    }

    public static Book findBookById(String sessionId){
        for (Book book:Books.getBooks()){
            if(book.getId().equals(sessionId)){
                //Toast.makeText(this, book.getName()+" ", Toast.LENGTH_SHORT).show();
                return book;
            }
        }
        return null;
    }
}

    /*public static boolean isUserLike(Book book)
    {
        return true;
        /*for (String str:book.getLikesList()){
            if (str.equals(Costumer.currentCostumer.getCostumerID())){
                return true;
            }
        }
        return false;*/



    /*public boolean searchByAutor(String author){
        String a="";
        for (int i=0;i<author.length();i++){
            a+=this.author.charAt(0);
        }
        return a.equals(author);
    }

    public boolean searchByName(String name){
        String a="";
        for (int i=0;i<name.length();i++){
            a+=this.name.charAt(0);
        }
        return a.equals(name);
    }*/

