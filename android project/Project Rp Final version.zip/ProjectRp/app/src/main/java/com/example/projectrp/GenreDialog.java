package com.example.projectrp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

import java.util.ArrayList;
/**
 * The class of the dialog to buy books
 */
/*public class GenreDialog extends AppCompatDialogFragment{
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_dialog_genre , null);

        builder.setView(view)
                .setTitle("Choose Your Genres!")
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Books.clearIsCheckedGenre();
                    }
                })
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        return builder.create();
    }
}*/

public class GenreDialog extends Dialog implements View.OnClickListener {
    Activity context;
    //Button btnBackFromFilter;
    Button btnOk;
    CheckBox cbLikedBooks;
    Button btnReset;
    public GenreDialog(@NonNull Context context) {
        super(context);
        this.context= (Activity) context;
    }
    public static boolean isFinished = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_dialog_genre);

        adptListView();
        initButton();

        if (LikeByUsers.showLiked){
            cbLikedBooks.setChecked(true);
        }


    }

    public void initButton(){
        //btnBackFromFilter=findViewById(R.id.btnBackFromFilter);
        btnReset=findViewById(R.id.btnReset);
        btnReset.setOnClickListener(this);
        cbLikedBooks = findViewById(R.id.cbLikedBooks);
        //btnBackFromFilter.setOnClickListener(this);
        cbLikedBooks.setOnClickListener(this);
        btnOk = findViewById(R.id.btnOk);
        btnOk.setOnClickListener(this);
    }


    public void adptListView(){

        ListView lvGenres = findViewById(R.id.lvGenre);
        Books.setGenreArrayList();
        ArrayList<String> genres =Books.getGenreArrayList();

        GenreListAdapter genreListAdapter = new GenreListAdapter(context, R.layout.genre_list_view, R.id.cbGenre, genres);
        System.out.println(lvGenres + " Hello World!");
        lvGenres.setAdapter(genreListAdapter);
    }

    /*public static boolean showLikedBooks(){
        return cbLikedBooks.isChecked();
    }*/

    @Override
    public void onClick(View view) {
        if (view == cbLikedBooks){
            System.out.println("Asdasdasdasda");
            LikeByUsers.showLiked = !LikeByUsers.showLiked;
        }
        else if(view == btnReset){
            LikeByUsers.showLiked = false;
            cbLikedBooks.setChecked(false);
            BooksActivity.isResetNow = true;
            isFinished = true;
            dismiss();
        }
        else if (view == btnOk){
            isFinished = true;
            //System.out.println("roee " + Books.getIsCheckedGenre().size());
            dismiss();
        }
    }
}
