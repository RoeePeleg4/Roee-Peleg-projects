package com.example.projectrp;

import android.app.Activity;
import android.content.Context;

import java.util.ArrayList;
/**
 * The class of the object of multiple book
 */
public class Books extends ArrayList<Book> {
    private static Books books = new Books();
    public static ArrayList<String> genreArrayList = new ArrayList<String>();
    public static ArrayList<String> isCheckedGenre = new ArrayList<String>();


    /*public static void getFromJson(Activity context) {

/*
        String json = "";
        if ((json = InternalFile.loadData(context, "books")) != null)

            books = Serialization.convertStringJsonToObject(Books.class, json);

        else
            books = Serialization.convertRawJsonToObject(Books.class, R.raw.books, context);
*/
    //}

    /*public static void saveToJson(Activity activity) {
        String json = Serialization.convertObjectToJson(books);
        InternalFile.saveData(activity, json, "books");
    }*/

    public static void updateStock(String id,int stock){
        for (int i=0;i<books.size();i++){
            if (books.get(i).getId().equals(id)){
                books.get(i).setStock(stock);
            }
        }
    }

    public static void updatePrice(String id,double price){
        for (int i=0;i<books.size();i++){
            if (books.get(i).getId().equals(id)){
                books.get(i).setPrice(price);
            }
        }
    }

    public static void removeBook(Book book){
        books.remove(book);
    }

    public static void setGenreArrayList(){
        ArrayList<String> genreArr = new ArrayList<String>();
        for (int i=0;i<books.size();i++){
            String genre = books.get(i).getGenre();
            if (!genreArr.contains(genre)){
                genreArr.add(genre);
            }
        }
        genreArrayList = genreArr;
    }

    public static void addBookToBooks(Book book){
        books.add(book);
    }

    public static void resetIsCheckedGenre(){
        isCheckedGenre.clear();
    }

    public static void addToIsCheckedGenre(String genre){
        isCheckedGenre.add(genre);
    }

    //until here!

    public static ArrayList<String> getIsCheckedGenre(){
        return isCheckedGenre;
    }

    /*public static void clearIsCheckedGenre(){
        isCheckedGenre.clear();
    }*/

    public static void removeFromIsCheckedGenre(String genre){
        isCheckedGenre.remove(genre);
    }

    public static ArrayList<String> getGenreArrayList (){
        return genreArrayList;
    }

    public static Books getBooks() {
        return books;
    }

    public static void setBooks(Books books) {
        Books.books = books;
    }
}
