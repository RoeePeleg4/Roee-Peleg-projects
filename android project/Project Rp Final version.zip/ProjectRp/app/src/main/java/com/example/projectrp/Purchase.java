package com.example.projectrp;
/**
 * The class for the object of purchase
 */
public class Purchase {
    //private boolean isSendSms;
    //private ArrayList<Purchase> sendSmsArray;
    private String date;
    private String purchaseId;
    private String userId;
    private String bookId;
    private double price;
    private boolean shipped; // is sent to the user
    private boolean delivery; // wants delivery or not
    private boolean isShippingNow;//is clicked for shipping

    public Purchase(String date, String purchaseId, String userId, String bookId, double price, boolean shipped, boolean delivery) {
        this.date = date;
        this.purchaseId = purchaseId;
        this.userId = userId;
        this.bookId = bookId;
        this.price = price;
        this.shipped = shipped;
        this.delivery = delivery;
        //this.isSendSms=false;
    }

    public void setShipped(boolean shipped) {
        this.shipped = shipped;
    }
    /*public boolean isSendSms() {
        return isSendSms;
    }

    public void setSendSms() {
        if (this.isSendSms){
            this.isSendSms=false;
        }else{
            this.isSendSms=true;
        }
    }*/


    public boolean getIsShippingNow() {
        return isShippingNow;
    }

    public void setShippingNow(boolean shippingNow) {
        isShippingNow = shippingNow;
    }

    public String getDate() {
        return date;
    }

    public String getPurchaseId() {
        return purchaseId;
    }

    public String getUserId() {
        return userId;
    }

    public String getBookId() {
        return bookId;
    }

    public double getPrice() {
        return price;
    }

    public boolean isShipped() {
        return shipped;
    }

    public boolean isDelivery() {
        return delivery;
    }

    /*public void addTosendSmsArray(String id){
        if (Purchases.findPurchaseById(id)!=null){
            sendSmsArray.add(Purchases.findPurchaseById(id));
        }

    }
    public void removeFromSmsArray(String id){
        for (int i=0;i<sendSmsArray.size();i++){
            if (sendSmsArray.get(i).getBookId().equals(id)){
                sendSmsArray.remove(i);
                return;
            }
        }
    }

    public static void getSendSmsSize(){
        System.out.println(sendSmsArray.size());
    }*/
}
