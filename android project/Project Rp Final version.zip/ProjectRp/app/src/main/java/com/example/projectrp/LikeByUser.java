package com.example.projectrp;
/**
 * The class that connecting users to their liked books
 */
public class LikeByUser {
    private String bookId;
    private String userId;

    public LikeByUser(String bookId, String userId) {
        this.bookId = bookId;
        this.userId = userId;
    }

    public String getBookId() {
        return bookId;
    }

    public String getUserById() {
        return userId;
    }

    /*public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }*/
}
