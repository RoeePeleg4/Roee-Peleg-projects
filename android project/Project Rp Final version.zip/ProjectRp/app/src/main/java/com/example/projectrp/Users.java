package com.example.projectrp;

import java.util.ArrayList;
/**
 * The class of the object of multiple user
 */
public class Users extends  ArrayList <User>{
    public static Users users =new Users();








    public static boolean checkIfIdOk(User user){
        for (int i = 0; i< users.size(); i++){
            if (user.getUserID().equals(users.get(i).getUserID()) && !(user.getUserID().equals(User.currentUser.getUserID()))){
                return false;
            }
        }
        return true;
    }
    public static void changeUsersDetails(User user){
        for (int i = 0; i< users.size(); i++){
            if (User.currentUser.getUserID().equals(users.get(i).getUserID())){
                users.set(i , user);
            }
        }
    }

    public static Users getUsers() {
        return users;
    }

    public static void setUsers(Users users) {
        Users.users = users;
    }
    public static void addUser(User user){
        Users.users.add(user);
        System.out.println(Users.users.size() + " hello world");
    }

    public static void setUserAsMannager(String id){
        for (int i = 0; i< users.size(); i++){
            if (users.get(i).getUserID().equals(id)){
                users.get(i).setManager(true);
            }
        }
    }

    public static void updateChanges(User user, String lastId){
        for (int i = 0; i< users.size(); i++){
            if (users.get(i).getUserID().equals(lastId)){
                users.set(i, user);
            }
        }
    }

    public static void setUserAsNotMannager(String id){
        for (int i = 0; i< users.size(); i++){
            if (users.get(i).getUserID().equals(id)){
                users.get(i).setManager(false);
            }
        }
    }

    public static User getUserById(String id){
        for (User user : Users.getUsers()){
            if (user.getUserID().equals(id)){
                return user;
            }
        }
        return null;
    }
}
