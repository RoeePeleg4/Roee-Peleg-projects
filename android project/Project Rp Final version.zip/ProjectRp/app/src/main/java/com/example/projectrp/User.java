package com.example.projectrp;
/**
 * The class of the object user
 */
public class User {
    public static User currentUser;
    private String userID;
    private String userFirstName;
    private String creditNumber;
    private boolean isManager;
    private String phoneNumber;
    private String address;
    private String userLastName;
    private String city;
    private String password;

    public User(String userID, String userFirstName, String creditNumber, String address, String userLastName, String city , String password , String phoneNumber , boolean isManager) {
        this.userID = userID;
        this.userFirstName = userFirstName;
        this.creditNumber = creditNumber;
        this.isManager=isManager;
        this.address = address;
        this.userLastName = userLastName;
        this.city = city;
        this.password=password;
        this.phoneNumber=phoneNumber;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setUserFirstName(String userFirstName) {
        this.userFirstName = userFirstName;
    }

    public void setCreditNumber(String creditNumber) {
        this.creditNumber = creditNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setUserLastName(String userLastName) {
        this.userLastName = userLastName;
    }


    public void setCity(String city) {
        this.city = city;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setManager(boolean manager) {
        isManager = manager;
    }

    public boolean isManager() {
        return isManager;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getPassword() {
        return password;
    }

    public String getUserID() {
        return userID;
    }

    public String getUserFirstName() {
        return userFirstName;
    }

    public String getCreditNumber() {
        return creditNumber;
    }

    public String getAddress() {
        return address;
    }

    public String getUserLastName() {
        return userLastName;
    }

    public String getCity() {
        return city;
    }
}
