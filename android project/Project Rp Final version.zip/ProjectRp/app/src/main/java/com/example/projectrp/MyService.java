package com.example.projectrp;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
/**
 * The class of the app's server
 */
public class MyService extends Service {
    public MyService() {
    }

    private static int tables=4;
    private static int finished=0;


    private static String updateCode = "";
    private static Context context;
    RestApi restApi = new RestApi();
    private static int counter=0;

    public String getUpdateCode() {
        return updateCode;
    }

    public void setUpdateCode(String updateCode) {
        this.updateCode = updateCode;
    }

    public static Context getContext() {
        return context;
    }

    public static void setContext(Context context) {
        MyService.context = context;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        counter++;

        if (counter!=1){
            return 0;
        }
        ServerPostCommunication serverPostCommunication = new ServerPostCommunication();

        new Thread(
                new Runnable() {
                    @Override
                    public void run() {

                        updateData();

                        while (true) {


                            updateData();

                            Log.e("Service", "Service is running " + updateCode + " hhh");


                            try {
                                Thread.sleep(10000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }


        ).start();


        return super.onStartCommand(intent, flags, startId);
    }


    public void updateData() {

        String code = restApi.getCodeUpdate();


        if (!code.equals(updateCode)) {

            updateCode = code;


            reload();


        }

    }

    /*String jsonCars = restApi.sqlCommand("select * from cars");

        System.out.println(jsonCars);
        try {
        Cars.setCars(Serialization.convertStringJsonToObject(Cars.class, jsonCars));

        System.out.println("the cars size if "+Cars.getCars().size());
    } catch (Exception e) {

    }*/


    public void reload() {
        String jsonBooks = restApi.sqlCommand("select * from books");

        System.out.println(jsonBooks);
        try {
            Books.setBooks(Serialization.convertStringJsonToObject(Books.class, jsonBooks));

            if(finished==0)
                finished=1;
        } catch (Exception e) {

        }

        String jsonUsers = restApi.sqlCommand("select * from users");

        System.out.println(jsonUsers);
        try {
            System.out.println("size of users is "+ Users.getUsers().size());

            Users.setUsers(Serialization.convertStringJsonToObject(Users.class, jsonUsers));
            System.out.println("size of users is "+ Users.getUsers().size());
            if(finished==1)
                finished=2;
        } catch (Exception e) {

        }


        String jsonPurchases = restApi.sqlCommand("select * from purchases");

        System.out.println(jsonPurchases);
        try {
            System.out.println("size of users is "+ Purchases.getPurchases().size());

            Purchases.setPurchases(Serialization.convertStringJsonToObject(Purchases.class, jsonPurchases));
            System.out.println("size of users is "+ Purchases.getPurchases().size());
            if(finished==2)
                finished=3;
        } catch (Exception e) {

        }

        String jsonLikeByUsers = restApi.sqlCommand("select * from likeByUsers");

        System.out.println(jsonLikeByUsers);
        try {

            LikeByUsers.setLikeByUsers(Serialization.convertStringJsonToObject(LikeByUsers.class, jsonLikeByUsers));
            System.out.println("size of users is "+ Users.getUsers().size());


            if(finished==3)
                finished=4;
        } catch (Exception e) {

        }

    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    public static int getTables() {
        return tables;
    }

    public static int getFinished() {
        return finished;
    }
}