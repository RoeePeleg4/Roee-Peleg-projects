package com.example.projectrp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
/**
 * The class activity that allows the manager to update book's details
 */
public class UpdateBooksDetailsActivity extends AppCompatActivity implements View.OnClickListener {
    EditText etBooksID;
    EditText etBooksStock;
    Button btnView;
    Button btnUpdate;
    Button btnClearDetails;
    //TextView tvShowDetails;
    Button btnRemoveBook;
    EditText etNewPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_stock);
        init();
    }

    public void init(){
        etNewPrice = findViewById(R.id.etNewPrice);
        btnRemoveBook = findViewById(R.id.btnRemoveBook);
        //tvShowDetails=findViewById(R.id.tvShowDetails);
        etBooksID=findViewById(R.id.etBooksID);
        etBooksStock=findViewById(R.id.etBooksStock);
        btnView=findViewById(R.id.btnView);
        btnUpdate=findViewById(R.id.btnUpdate);
        btnClearDetails=findViewById(R.id.btnClearDetails);
        btnView.setOnClickListener(this);
        btnUpdate.setOnClickListener(this);
        btnClearDetails.setOnClickListener(this);
        btnRemoveBook.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == btnClearDetails){
            etBooksID.setText("");
            etBooksStock.setText("");
            //tvShowDetails.setText("");
            return;
        }
        String bookId = etBooksID.getText().toString();
        Book book = Book.findBookById(bookId);
        if (book == null){
            Toast.makeText(this, "Book is'nt exist", Toast.LENGTH_SHORT).show();
            return;
        }
        if (view == btnView){
            Toast.makeText(this, book.getName(), Toast.LENGTH_SHORT).show();
            //tvShowDetails.setText(book.getName());
        }else if (view == btnUpdate){
            int stock = 0;
            double price = 0;
            if (etNewPrice.getText().toString().equals("") && etBooksStock.getText().toString().equals("")){
                return;
            }else if (etNewPrice.getText().toString().equals("")){
                try{
                    stock = Integer.parseInt(etBooksStock.getText().toString());
                }catch (Exception e){
                    Toast.makeText(this, "You have to enter a number in the stock", Toast.LENGTH_SHORT).show();
                    return;
                }
                Books.updateStock(bookId , stock);
                updateTheServerBooks();
                Toast.makeText(this, "Server has been updadated", Toast.LENGTH_SHORT).show();
                etBooksID.setText("");
                etBooksStock.setText("");
                //tvShowDetails.setText("");
                etNewPrice.setText("");
                return;
            }else if (etBooksStock.getText().toString().equals("")){
                try{
                    price = Double.parseDouble(etNewPrice.getText().toString());
                }catch (Exception e){
                    Toast.makeText(this, "You have to enter a number in the price", Toast.LENGTH_SHORT).show();
                    return;
                }
                Books.updatePrice(bookId , price);
                updateTheServerBooks();
                Toast.makeText(this, "Server has been updadated", Toast.LENGTH_SHORT).show();
                etBooksID.setText("");
                etBooksStock.setText("");
                //tvShowDetails.setText("");
                etNewPrice.setText("");
                return;
            }
            try{
                stock = Integer.parseInt(etBooksStock.getText().toString());
                price = Double.parseDouble(etNewPrice.getText().toString());
            }catch (Exception e){
                Toast.makeText(this, "You have to enter a number in the price and in the stock", Toast.LENGTH_SHORT).show();
                return;
            }
            Books.updateStock(bookId , stock);
            Books.updatePrice(bookId , price);
            updateTheServerBooks();
            Toast.makeText(this, "Server has been updadated", Toast.LENGTH_SHORT).show();
            etBooksID.setText("");
            etBooksStock.setText("");
            //tvShowDetails.setText("");
            etNewPrice.setText("");
        }else if (view == btnRemoveBook){
            Books.removeBook(book);
            updateTheServerBooks();
            etBooksID.setText("");
            etBooksStock.setText("");
            //tvShowDetails.setText("");
            etNewPrice.setText("");
            Toast.makeText(this, "Book has been deleted", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuback, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.backToMainMannger:
                Intent intent=new Intent(this,MainManagerActivity.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


    public void updateTheServerBooks(){




        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();
                        //service.updateData();



                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {


                            }
                        });
                        String bookId = etBooksID.getText().toString();
                        Book book = Book.findBookById(bookId);

                        RestApi restApi = new RestApi();
                        //restApi.saveFile("jsons/books.json",   Serialization.convertObjectToJson(Books.getBooks()));
                        restApi.sqlCommand("update books set stock=\""+book.getStock()+"\" where id=\""+bookId+"\"");
                        restApi.sqlCommand("update books set price=\""+book.getPrice()+"\" where id=\""+bookId+"\"");

                    }
                }


        ).start();






        //  Books.saveToJson(this);
    }
}