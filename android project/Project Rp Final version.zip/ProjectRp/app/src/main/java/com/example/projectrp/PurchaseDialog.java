package com.example.projectrp;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
/**
 * The class dialog of the dialog that confirms the purchase
 */
public class PurchaseDialog extends Dialog implements View.OnClickListener {
    private EditText etConfirmPasswordToPay;
    private CheckBox cbWantShipping;
    private Button btnPay;
    private Button btnBackBookPage;
    private String idDialog;
    Activity context;
    public static boolean isPurchused;

    public PurchaseDialog(@NonNull Context context) {
        super(context);
        this.context = (Activity) context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_dialog_purchase);
        isPurchused = false;
        init();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onClick(View view) {
        if (view == btnBackBookPage) {
            dismiss();
        } else if (view == btnPay) {
            if (etConfirmPasswordToPay.getText().toString().equals(User.currentUser.getPassword())) {
                Purchase purchase = createPurchaseIntent();
                //Toast.makeText(context, , Toast.LENGTH_SHORT).show();
                updateTheServerPurchases(purchase);
                System.out.println("roee id: " + purchase.getBookId() + "Peleg id: " + purchase.getUserId());
                User user = Users.getUserById(purchase.getUserId());
                isPurchused = true;

                if (purchase.isDelivery()) {
                    //SendSms.sendSMS(costumer.getPhoneNumber() , "Hi" + costumer.getCostumerFirstName() + " " + costumer.getCostumerLastName() + "\n" + "your order " + purchase.getPurchaseId() + " had been paid.\n stay tuned for updates" , context);
                } else {
                    //SendSms.sendSMS(costumer.getPhoneNumber() , "Hi" + costumer.getCostumerFirstName() + " " + costumer.getCostumerLastName() + "\n" + "your order " + purchase.getPurchaseId() + " had been paid.\n you can come to the store to pick it up!" , context);
                }
            } else {
                Toast.makeText(context, "Wrong password", Toast.LENGTH_SHORT).show();
            }
            dismiss();
        }
    }

    public void init() {
        etConfirmPasswordToPay = findViewById(R.id.etConfirmPasswordToPay);
        cbWantShipping = findViewById(R.id.cbWantShipping);
        btnBackBookPage = findViewById(R.id.btnBackBookPage);
        btnPay = findViewById(R.id.btnPay);
        btnBackBookPage.setOnClickListener(this);
        btnPay.setOnClickListener(this);
    }
    /*@NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder=new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_dialog_purchase , null);


        builder.setView(view)
                .setTitle("Confirm password in order to pay")
                .setNegativeButton("back", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton("pay", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (etConfirmPasswordToPay.getText().toString().equals(Costumer.currentCostumer.getPassword())){
                            Purchase purchase=createPurchaseIntent();
                            System.out.println("roee id: " + purchase.getBookId() + "Peleg id: " + purchase.getCostumerId());
                            updateTheServerPurchases(purchase);
                            Costumer costumer=Costumers.getCostumerById(purchase.getCostumerId());
                            isPurchused=true;
                            if (purchase.isDelivery()){
                                //SendSms.sendSMS(costumer.getPhoneNumber() , "Hi" + costumer.getCostumerFirstName() + " " + costumer.getCostumerLastName() + "\n" + "your order " + purchase.getPurchaseId() + " had been paid.\n stay tuned for updates" , context);
                            }else{
                                //SendSms.sendSMS(costumer.getPhoneNumber() , "Hi" + costumer.getCostumerFirstName() + " " + costumer.getCostumerLastName() + "\n" + "your order " + purchase.getPurchaseId() + " had been paid.\n you can come to the store to pick it up!" , context);
                            }
                        }
                    }
                });

        return builder.create();
    }*/

    @RequiresApi(api = Build.VERSION_CODES.O)
    public Purchase createPurchaseIntent() {
        DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDateTime date = LocalDateTime.now();
        System.out.println(dtf1.format(date));


        DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        LocalDateTime idPurchase = LocalDateTime.now();
        System.out.println(dtf2.format(idPurchase));

        String userId = User.currentUser.getUserID();

        String bookId = Book.currentBookOnDialog.getId();

        double price = Book.currentBookOnDialog.getPrice();

        boolean shipped = false;
        boolean delivery = false;

        if (cbWantShipping.isChecked()) {
            delivery = true;
        }


        Purchase purchase = new Purchase(dtf1.format(date), dtf2.format(idPurchase), userId, bookId, price, shipped, delivery);

        return purchase;
    }

    public void updateTheServerPurchases(Purchase purchase) {


        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        MyService service = new MyService();

                        System.out.println("asdasdasdasdsada");


                        RestApi restApi = new RestApi();
                        Purchases.addPurchase(purchase);
                        System.out.println("size harry " + Purchases.getPurchases().size());
                        //Toast.makeText(context, Purchases.getPurchases().get(Purchases.getPurchases().size()-1).getCostumerId() + " ", Toast.LENGTH_SHORT).show();
                        Book book = Book.currentBookOnDialog;
                        System.out.println(Purchases.getPurchases().size() + " in the thread");
                        restApi.twoSqlCommand("insert into purchases (date, purchaseId, userId, bookId, price, shipped, delivery) values (\""+purchase.getDate()+"\",\""+purchase.getPurchaseId()+"\",\""+purchase.getUserId()+"\",\""+purchase.getBookId()+"\",\""+purchase.getPrice()+"\",\""+false+"\", \""+purchase.isDelivery()+"\");update books set stock=stock-1 where id=\""+book.getId()+"\"");
                        //restApi.sqlCommand(command);
                        //System.out.println("the command is " +command);
                        //System.out.println("command is " + command);

                    }
                }


        ).start();


        //  Books.saveToJson(this);
    }

    public static boolean isPurchased() {
        return isPurchused;
    }


}
