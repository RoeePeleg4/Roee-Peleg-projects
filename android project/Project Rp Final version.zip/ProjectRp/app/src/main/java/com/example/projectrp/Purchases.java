package com.example.projectrp;

import android.widget.Toast;

import java.util.ArrayList;
/**
 * The class of the object of multiple purchase
 */
public class Purchases extends ArrayList<Purchase> {
    //private static ArrayList<Purchase> sendSmsArray;
    //private static ArrayList<Purchase> costumersToSendSms = new ArrayList<Purchase>();
    private static Purchases purchases = new Purchases();
    public static Purchases getPurchases() {
        return purchases;
    }

    public static void setPurchases(Purchases purchases) {
        Purchases.purchases = purchases;
    }
    public static void addPurchase(Purchase purchase){
        Purchases.purchases.add(purchase);
    }
    /*public static void setPurchasesByClicked(){
        for (int i=0;i<purchases.size();i++){
            if (purchases.get(i).isShippingNow()){
                System.out.println("hi there you");
                purchases.remove(i);
                i--;
            }
        }
    }*/
    /*
    public static void changeToShipped(Purchase purchase){
        purchases.
    }
*/
    public static ArrayList<Purchase> filterByNotShipped(){
        ArrayList<Purchase> purchasesToShow = new ArrayList<Purchase>();
        for (int i=0;i<purchases.size();i++){
            if (!purchases.get(i).isShipped()){
                purchasesToShow.add(purchases.get(i));
            }
        }
        return purchasesToShow;
    }


    /*public static void addTosendSmsArray(String id){
        if (findPurchaseById(id)!=null){
            sendSmsArray.add(findPurchaseById(id));
        }

    }
    public static void removeFromSmsArray(String id){
        for (int i=0;i<sendSmsArray.size();i++){
            if (sendSmsArray.get(i).getBookId().equals(id)){
                sendSmsArray.remove(i);
                return;
            }
        }
    }

    public static Purchase findPurchaseById(String id){
        for (int i=0;i<purchases.size();i++){
            if (purchases.get(i).getBookId().equals(id)){
                return purchases.get(i);
            }
        }
        return null;
    }
    public static void getSendSmsSize(){
        System.out.println(sendSmsArray.size());
    }*/
}
